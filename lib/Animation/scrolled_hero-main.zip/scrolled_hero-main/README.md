### Example of fixed hero animation on scrolled item. 

![Alt Text](https://github.com/zombie6888/scrolled_hero/blob/main/hero_app/fixed_hero.gif?raw=true)
